package project;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;

import game.baseball.BaseBallGame;

public class BaseBallGameView {
		

	// 중앙에 들어갈 속지 선언
	JPanel jp_center = new JPanel();
	JFrame jf = new JFrame();
	//세자리 숫자를 입력 후 엔터를 쳤을때 사용자가 입력한 숫자와 수자를 맞추기 위한 힌트문
	//을 출력해 줄 화면 이다.
	JScrollPane jsp_display = null;
	JTextArea jta_display = null;
	JTextField jtf_user = new JTextField();
	////////// 메뉴 바 ///////////////
	String imgPath = "C:\\workspace_java\\dev_java\\src\\game\\baseball\\";
	// ImageIcon bg = new ImageIcon(imgPath+"BackGround.jpg");
	Image img = jf.getToolkit().getImage(imgPath+"BackGround.jpg");
	//이미지 버튼을 만드는데 필요한 클래스 선언하기
	JButton jbtn_inew = new JButton();
	JButton jbtn_iclear= new JButton();
	JButton jbtn_idap = new JButton();
	JMenuBar jmb = new JMenuBar();
	JMenu jm_file = new JMenu("File (F)");
	JMenuItem jmi_new = new JMenuItem("새게임 (N)");
	JMenuItem jmi_dap = new JMenuItem("정답 (D)");
	JMenuItem jmi_exit = new JMenuItem("나가기");
	JMenuItem jmi_option = new JMenuItem("옵션 (O)");
	JMenuItem jmi_easy = new JMenuItem("Easy Mode (E)");
	JMenuItem jmi_normal = new JMenuItem("Normal Mode (N)");
	JMenuItem jmi_hard = new JMenuItem("Hard Mode (H)");
	JMenu jm_edit = new JMenu("Edit (E)");
	JMenuItem jmi_copy = new JMenuItem("Copy");
	JMenuItem jmi_cut = new JMenuItem("Cut");
	JMenuItem jmi_paste = new JMenuItem("Paste");
	JMenu jm_help = new JMenu("도움말 (H)");
	JMenuItem jmi_help1 = new JMenuItem("제작자");
	JMenuItem jmi_help3 = new JMenuItem("야구 숫자 게임 이란?");
	JMenuItem jmi_help2 = new JMenuItem("만든 사람 들");
	Font f = new Font("Thoma", Font.BOLD, 14);
	JPanel jp_east = new JPanel();
	JButton jbtn_new = new JButton("새게임");
	JButton jbtn_dap = new JButton("정답");
	JButton jbtn_clear = new JButton("지우기");
	JButton jbtn_exit = new JButton("나가기");
	JToolBar toolbar = new JToolBar();
	
	public void initDisplay() {
		img = jf.getToolkit().getImage(imgPath+"BackGround.jpg");
		jta_display = new JTextArea() {
		private static final long serialVersionUID = 1L;

		public void paint(Graphics g) {
			g.drawImage(img, 0, 0, null);
			Point p = jsp_display.getViewport().getViewPosition();
			g.drawImage(img, p.x, p.y, null);
			paintComponent(g);
		}
};
		jsp_display = new JScrollPane(jta_display);
		jta_display.setOpaque(false);
		System.out.println("initDisplay 호출 성공");
		/*
		//이벤트 소스와 이벤트 처리 클래스를 매핑하는 코드 추가
		//EventHandler ehandler = EventHandler
		
		//jtf_user.addActionListener(ehandler); // 여기서 this 는 자기자신 클래스를 가리킴.
		jtf_user.addActionListener(this); // 여기서 this 는 자기자신 클래스(BaseBallGame)를 가리킴.
		jbtn_exit.addActionListener(this); // 여기서 this 는 자기자신 클래스(BaseBallGame)를 가리킴.
		jbtn_new.addActionListener(this); // 여기서 this 는 자기자신 클래스(BaseBallGame)를 가리킴.
		jbtn_dap.addActionListener(this); // 여기서 this 는 자기자신 클래스(BaseBallGame)를 가리킴.
		jbtn_clear.addActionListener(this); // 여기서 this 는 자기자신 클래스(BaseBallGame)를 가리킴.
		jmi_exit.addActionListener(this); // 여기서 this 는 자기자신 클래스(BaseBallGame)를 가리킴.
		//- BaseBallGame : 내 안에 actionPerformed
		//// 위에 창 메뉴 //////////
		// 툴바에 들어갈 이미지 버튼 추가하기 ///
		 * 
		 */
		jbtn_inew.setIcon(new ImageIcon(imgPath+"new.gif"));
		jbtn_iclear.setIcon(new ImageIcon(imgPath+"delete.gif"));
		jbtn_idap.setIcon(new ImageIcon(imgPath+"detail.gif"));
		toolbar.add(jbtn_inew);
		toolbar.add(jbtn_iclear);
		toolbar.add(jbtn_idap);
		////////// 메뉴바 단축키 ////////
		/////////// 메뉴바 시작 및 단축키 //////////
		jm_file.add(jmi_new);
		jmi_new.setMnemonic('N');
		jm_file.add(jmi_dap);
		jmi_dap.setMnemonic('D');
		jm_file.add(jmi_option);
		jmi_option.setMnemonic('O');
		jm_file.add(jmi_easy);
		jmi_easy.setMnemonic('E');
		jm_file.add(jmi_normal);
		jmi_normal.setMnemonic('N');
		jm_file.add(jmi_hard);
		jmi_hard.setMnemonic('H');
		jm_file.add(jmi_exit);
		jmi_exit.setMnemonic('X');
		jm_edit.add(jmi_copy);
		jm_edit.add(jmi_cut);
		jm_edit.add(jmi_paste);
		jm_help.add(jmi_help1);
		jm_help.add(jmi_help2);
		jm_help.add(jmi_help3);
		jmb.add(jm_file);
		jm_file.setMnemonic('F');
		jmb.add(jm_edit);
		jm_edit.setMnemonic('E');
		jmb.add(jm_help);
		jm_help.setMnemonic('H');
		//////////////// 메뉴바 끝 및 단축키 /////////////////
		jta_display.setFont(f);
		jbtn_new.setForeground(new Color(255,255,255));
		jbtn_new.setBackground(new Color(158,9,9));
		jbtn_dap.setForeground(new Color(255,255,255));
		jbtn_dap.setBackground(new Color(7,84,170));
		jbtn_clear.setForeground(new Color(255,255,255));
		jbtn_clear.setBackground(new Color(19,99,57));
		jbtn_exit.setForeground(new Color(255,255,255));
		jbtn_exit.setBackground(new Color(54,54,54));
		jta_display.setForeground(new Color(255,255,255));
		jta_display.setBackground(new Color(255,216,216));
		jtf_user.setBackground(new Color(255,255,200));
		jp_center.setBackground(new Color(212,244,250));
		//jp_center.setBackground(Color.);
		jp_east.setBackground(Color.yellow);
		jp_east.setLayout(new GridLayout(4,1));
		jp_east.add(jbtn_new);
		jp_east.add(jbtn_dap);
		jp_east.add(jbtn_clear);
		jp_east.add(jbtn_exit);
		jp_center.setLayout(new BorderLayout(0,10));
		jp_center.add("Center",jsp_display);
		jp_center.add("South",jtf_user);
		jta_display.setLineWrap(true);
		jf.setLayout(new BorderLayout(0,10));
		jf.add("North",toolbar);
		jf.add("Center",jp_center);
		jf.add("East",jp_east);
		jf.setTitle("야구 숫자 게임 Ver1.0");
		jf.setJMenuBar(jmb);
		jf.setSize(700, 900);
		jf.setVisible(true);
		
	}
}
